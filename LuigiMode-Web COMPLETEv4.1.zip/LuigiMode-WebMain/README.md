This Mod was created by floog98 DO NOT REPOST ANYWHERE OR CLAIM AS YOUR OWN, You can make videos using this mod but you must make the video family friendly and say in the video and description that I (floog98) made this and in the description of the video give a link to the download

SMAS-SMB1 CREDITS:floog98 (made entire mod and all SMC custom sprites)
	Nintendo (made original luigi)
	LinkstormZ (made Hammer Luigi, but floog98 made all SMC custom sprites for 	Hammer Luigi)

SMW CREDITS: Luigi, Super Luigi, Fire Luigi, Racoon Luigi, Hammer Luigi, Ice Luigi, Bunny Luigi, Tanooki Luigi and Bubble Luigi are in sprite sheets by: GlacialSiren484, TheMushrunt, CaptainGame17, Jamestendo64, AwesomeZack, LinkstormZ, MauricioN64 and Amer. Cloud Luigi was a re-colour of luigi in those previous sprite sheets and the cloud by Uniido (Making Cloud Animation made from custom pixels and sprite sheets) 

